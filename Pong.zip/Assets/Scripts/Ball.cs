using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Ball : MonoBehaviour
{
    public Vector3 _initialPosition;
    public RectTransform _rectTransform;
    public Vector2 _positionToTranslate;
    [SerializeField] private float _moveSpeed = 140f;
    private string _boundaryTag = "Boundary";
    private string _playerTag = "Player";

    [Header("Minmax values")]
    [SerializeField] private float minValue;
    [SerializeField] private float maxValue;

    // Start is called before the first frame update
    void Start()
    {
        _rectTransform = GetComponent<RectTransform>();
        _initialPosition = _rectTransform.localPosition;
    }

    // Update is called once per frame
    void Update()
    {
        MoveBall();
    }

    private void MoveBall()
    {
        _rectTransform.Translate(_positionToTranslate * _moveSpeed * Time.deltaTime);
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.CompareTag(_boundaryTag))
        {
            ReverseYPosition();
        }
        if (collision.gameObject.CompareTag(_playerTag))
        {
            ReverseXPosition();
        }
    }

    private void ReverseYPosition()
    {
        float newYValue = Random.Range(minValue, maxValue);
        _positionToTranslate.y = ChangeVectorAxisValue(_positionToTranslate.y, newYValue);
        RandomizeMoveSpeed();
    }

    private void ReverseXPosition()
    {
        float newXValue = Random.Range(minValue, maxValue);
        _positionToTranslate.x = ChangeVectorAxisValue(_positionToTranslate.x, newXValue);
        RandomizeMoveSpeed();
    }

    private float ChangeVectorAxisValue( float axisValue, float axisNewValue )
    {
        if (axisValue < 0)
        {
            axisValue = axisNewValue;
            return axisValue;
        }
        axisValue = -axisNewValue;
        return axisValue;
    }

    private void RandomizeMoveSpeed()
    {
       // _moveSpeed = Random.Range(140f, 180f);
    }
}
